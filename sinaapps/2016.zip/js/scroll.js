/*var s_bak = 0;
var s = 0;
window.onscroll = function(){
	var p = document.body.scrollTop;
	var q = window.innerHeight;
	s = p+q;
	document.getElementById("logo").innerHTML=s;
	document.getElementById("logo").innerHTML+=document.getElementById("backpic1").height;
}
*/